# app.py

import subprocess
from flask import Flask, render_template, request, jsonify, session, redirect, url_for

app = Flask(__name__)
app.secret_key = '47eea5ff7548a55c53bfa1d124a780be'  # Set a secret key for session encryption

@app.route('/')
def home():
    if 'username' in session:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))

@app.route('/execute_command', methods=['POST'])
def execute_command():
    if 'username' in session:
        command = request.form['command']
        output = process_command(command)
        return jsonify({'output': output})
    else:
        return redirect(url_for('login'))

def process_command(command):
    try:
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        return result
    except subprocess.CalledProcessError as e:
        return f'Command execution failed with error code {e.returncode}: {e.output}'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'krodnu' and password == '123':
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='Invalid credentials')
    else:
        if 'username' in session:
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
